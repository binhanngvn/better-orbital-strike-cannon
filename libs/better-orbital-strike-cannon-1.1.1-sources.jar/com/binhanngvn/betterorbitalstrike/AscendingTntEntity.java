package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_1299;
import net.minecraft.class_1541;
import net.minecraft.class_1937;
import net.minecraft.class_2680;

public class AscendingTntEntity extends class_1541 {
    private double progress = 0;
    private final double maxHeight = 72.5;
    private double startY;

    public AscendingTntEntity(class_1299<? extends class_1541> entityType, class_1937 world) {
        super(entityType, world);
        this.startY = this.method_23318();
        this.method_6967(367);
        this.method_5875(true);
    }

    public static AscendingTntEntity create(class_1937 world, double x, double y, double z) {
        AscendingTntEntity entity = new AscendingTntEntity(OrbitalStrikeMod.ASCENDING_TNT_ENTITY_TYPE, world);
        entity.method_5814(x, y, z);
        entity.startY = y;
        return entity;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        if (!this.method_73183().method_8608()) {
            progress += 0.02;
            if (progress > 1) progress = 1;

            double ease = easeInOut(progress);
            double targetY = startY + (maxHeight * ease);

            this.method_5814(this.method_23317(), targetY, this.method_23321());

            float rotSpeed = (float)(progress * 20);
            this.method_36456(this.method_36454() + rotSpeed);
        }
    }

    @Override
    public class_2680 method_54456() {
        return ModBlocks.NUKE_CLEAR.method_9564();
    }

    private double easeInOut(double t) {
        return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    }
}