package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class CustomRodItem extends class_1792 {

    public CustomRodItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {

        if (world.method_8608()) return class_1269.field_5811;

        class_1799 stack = user.method_5998(hand);

        // ép item còn đúng 1 durability
        if (stack.method_7919() == 0) {
            stack.method_7974(63);
        }

        class_3218 serverWorld = (class_3218) world;

        // Ép kiểu người chơi để truyền vào hàm lấy thành tựu
        class_3222 serverPlayer = (class_3222) user;

        class_243 start = user.method_33571();
        class_243 dir = user.method_5828(1.0f);

        class_2338 target = null;

        for (int i = 1; i <= 512; i++) {
            class_243 point = start.method_1019(dir.method_1021(i));
            class_2338 pos = class_2338.method_49638(point);

            if (!world.method_8393(pos.method_10263() >> 4, pos.method_10260() >> 4)) continue;

            if (!world.method_8320(pos).method_26215()) {
                target = pos;
                break;
            }
        }

        if (target == null) return class_1269.field_5814;

        class_2338 finalTarget = target;

        // ===== STAB =====
        if (stack.method_31574(ModItems.STAB_SHOT)) {
            OrbitalstrikesLogic.spawnStabStrike(serverWorld, finalTarget, serverPlayer);
            breakItem(stack, user, hand);
            return class_1269.field_5812;
        }

        // ===== NUKE =====
        if (stack.method_31574(ModItems.NUKE_SHOT)) {
            OrbitalStrikes.runVisualEffect(serverWorld, finalTarget, 38.0, 60);
            OrbitalstrikesLogic.spawnNuke(serverWorld, finalTarget, serverPlayer);
            breakItem(stack, user, hand);
            return class_1269.field_5812;
        }

        // ===== LAWNUKE =====
        if (stack.method_31574(ModItems.LAWNUKE_SHOT)) {
            OrbitalStrikes.runVisualEffect(serverWorld, finalTarget, 65.0, 60);
            OrbitalstrikesLogic.spawnLawnuke(serverWorld, finalTarget, serverPlayer);
            breakItem(stack, user, hand);
            return class_1269.field_5812;
        }

        return class_1269.field_5811;
    }

    private void breakItem(class_1799 stack, class_1657 user, class_1268 hand) {

        user.method_23667(hand, true);

        boolean wasCreative = user.method_31549().field_7477;

        try {

            if (wasCreative) {
                user.method_31549().field_7477 = false;
            }

            stack.method_7970(
                    1,
                    user,
                    hand == class_1268.field_5808
                            ? class_1304.field_6173
                            : class_1304.field_6171
            );

        } finally {

            if (wasCreative) {
                user.method_31549().field_7477 = true;

                if (user instanceof class_3222 sp) {
                    sp.method_7355();
                }
            }
        }
    }
}