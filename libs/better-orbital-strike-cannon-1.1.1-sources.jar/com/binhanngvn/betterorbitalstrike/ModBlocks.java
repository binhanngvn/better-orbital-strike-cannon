package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_1541;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

public class ModBlocks {
    public static final class_2248 TNT_X9 = registerX9("tnt_x9");
    public static final class_2248 TNT_X18 = registerX18("tnt_x18");
    public static final class_2248 NUKE_CLEAR = registerNukeClear("nuke_clear");

    private static class_2248 registerX9(String name) {
        class_2960 id = class_2960.method_60655("betterorbitalstrike", name);
        class_5321<class_2248> key = class_5321.method_29179(class_7923.field_41175.method_46765(), id);

        return class_2378.method_39197(class_7923.field_41175, key, new class_2530(class_4970.class_2251.method_9637()
                .method_63500(key).method_36557(0.0f).method_9626(class_2498.field_11535)) {

            @Override
            public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
                if (!world.method_8608() && world.method_49803(pos)) {
                    primeTntX9((net.minecraft.class_3218) world, pos, 80, null);
                    world.method_8650(pos, false);
                }
            }

            @Override
            public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, @Nullable net.minecraft.class_9904 wireOrientation, boolean notify) {
                if (!world.method_8608() && world.method_49804(pos) > 0) {
                    primeTntX9((net.minecraft.class_3218) world, pos, 80, null);
                    world.method_8650(pos, false);
                }
            }

            @Override
            public net.minecraft.class_1269 method_55765(net.minecraft.class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1657 player, net.minecraft.class_1268 hand, net.minecraft.class_3965 hit) {
                if (stack.method_31574(net.minecraft.class_1802.field_8884) || stack.method_31574(net.minecraft.class_1802.field_8814)) {
                    if (!world.method_8608()) {
                        world.method_8650(pos, false);
                        primeTntX9((net.minecraft.class_3218) world, pos, 80, player);
                    }
                    return net.minecraft.class_1269.field_5812;
                }
                return super.method_55765(stack, state, world, pos, player, hand, hit);
            }

            @Override
            public void method_55124(class_2680 state, net.minecraft.class_3218 world, class_2338 pos, class_1927 explosion, java.util.function.BiConsumer<net.minecraft.class_1799, class_2338> stackMerger) {
                world.method_8650(pos, false);
                primeTntX9(world, pos, 10, null);
            }
        });
    }

    private static class_2248 registerX18(String name) {
        class_2960 id = class_2960.method_60655("betterorbitalstrike", name);
        class_5321<class_2248> key = class_5321.method_29179(class_7923.field_41175.method_46765(), id);

        return class_2378.method_39197(class_7923.field_41175, key, new class_2530(class_4970.class_2251.method_9637()
                .method_63500(key).method_36557(0.0f).method_9626(class_2498.field_11535)) {

            @Override
            public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
                if (!world.method_8608() && world.method_49803(pos)) {
                    primeTntX18((net.minecraft.class_3218) world, pos, 80, null);
                    world.method_8650(pos, false);
                }
            }

            @Override
            public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, @Nullable net.minecraft.class_9904 wireOrientation, boolean notify) {
                if (!world.method_8608() && world.method_49804(pos) > 0) {
                    primeTntX18((net.minecraft.class_3218) world, pos, 80, null);
                    world.method_8650(pos, false);
                }
            }

            @Override
            public net.minecraft.class_1269 method_55765(net.minecraft.class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1657 player, net.minecraft.class_1268 hand, net.minecraft.class_3965 hit) {
                if (stack.method_31574(net.minecraft.class_1802.field_8884) || stack.method_31574(net.minecraft.class_1802.field_8814)) {
                    if (!world.method_8608()) {
                        world.method_8650(pos, false);
                        primeTntX18((net.minecraft.class_3218) world, pos, 80, player);
                    }
                    return net.minecraft.class_1269.field_5812;
                }
                return super.method_55765(stack, state, world, pos, player, hand, hit);
            }

            @Override
            public void method_55124(class_2680 state, net.minecraft.class_3218 world, class_2338 pos, class_1927 explosion, java.util.function.BiConsumer<net.minecraft.class_1799, class_2338> stackMerger) {
                world.method_8650(pos, false);
                primeTntX18(world, pos, 10, null);
            }
        });
    }

    private static class_2248 registerNukeClear(String name) {
        class_2960 id = class_2960.method_60655("betterorbitalstrike", name);
        class_5321<class_2248> key = class_5321.method_29179(class_7923.field_41175.method_46765(), id);

        return class_2378.method_39197(class_7923.field_41175, key, new class_2530(class_4970.class_2251.method_9637()
                .method_63500(key).method_36557(0.0f).method_9626(class_2498.field_11535)) {

            @Override
            public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
                if (!world.method_8608() && world.method_49803(pos)) {
                    primeNukeClear((net.minecraft.class_3218) world, pos, null);
                }
            }

            @Override
            public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, @Nullable net.minecraft.class_9904 wireOrientation, boolean notify) {
                if (!world.method_8608() && world.method_49804(pos) > 0) {
                    primeNukeClear((net.minecraft.class_3218) world, pos, null);
                }
            }

            @Override
            public net.minecraft.class_1269 method_55765(net.minecraft.class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1657 player, net.minecraft.class_1268 hand, net.minecraft.class_3965 hit) {
                if (stack.method_31574(net.minecraft.class_1802.field_8884) || stack.method_31574(net.minecraft.class_1802.field_8814)) {
                    if (!world.method_8608()) {
                        primeNukeClear((net.minecraft.class_3218) world, pos, player);
                    }
                    return net.minecraft.class_1269.field_5812;
                }
                return super.method_55765(stack, state, world, pos, player, hand, hit);
            }

            @Override
            public void method_55124(class_2680 state, net.minecraft.class_3218 world, class_2338 pos, class_1927 explosion, java.util.function.BiConsumer<net.minecraft.class_1799, class_2338> stackMerger) {
                primeNukeClear(world, pos, null);
            }
        });
    }

    public static void primeNukeClear(net.minecraft.class_3218 world, class_2338 pos, @Nullable net.minecraft.class_1309 causer) {
        if (causer instanceof net.minecraft.class_3222 player) {
            net.minecraft.class_8779 adv = world.method_8503().method_3851().method_12896(net.minecraft.class_2960.method_60655("betterorbitalstrike", "nuke_clear"));
            if (adv != null) player.method_14236().method_12878(adv, "use_nuke_clear");
        }

        world.method_8650(pos, false);

        OrbitalStrikes.spawnAscendingBeam(world, pos);
        OrbitalStrikes.runVisualEffect(world, pos, 61.0, 60);

        new Thread(() -> {
            try { Thread.sleep(100); } catch (Exception ignored) {}

            world.method_8503().execute(() -> {
                OrbitalStrikes.spawnAscendingTnt(world, pos);
            });

            try { Thread.sleep(2500); } catch (Exception ignored) {}

            world.method_8503().execute(() -> {
                OrbitalstrikesLogic.spawnLawnuke(world, pos);
                OrbitalStrikes.clearAscendingTnt(world, pos);
            });

            try { Thread.sleep(4000); } catch (Exception ignored) {}

            world.method_8503().execute(() -> {
                OrbitalStrikes.spawnStabRingWave(world, pos);
            });

        }).start();
    }

    public static void primeTntX9(net.minecraft.class_3218 world, class_2338 pos, int baseFuse, @Nullable net.minecraft.class_1309 causer) {
        if (causer instanceof net.minecraft.class_3222 player) {
            net.minecraft.class_8779 adv = world.method_8503().method_3851().method_12896(net.minecraft.class_2960.method_60655("betterorbitalstrike", "tnt_x9"));
            if (adv != null) player.method_14236().method_12878(adv, "use_tnt_x9");
        }

        for (int i = 0; i < 9; i++) {
            class_1541 tnt = new class_1541(world, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, causer);
            tnt.method_6967(baseFuse + (i * 1));
            double angle = 2 * Math.PI * i / 9;
            double speed = 0.3;
            tnt.method_18800(Math.cos(angle) * speed, 0.2, Math.sin(angle) * speed);
            world.method_8649(tnt);
        }
    }

    public static void primeTntX18(net.minecraft.class_3218 world, class_2338 pos, int baseFuse, @Nullable net.minecraft.class_1309 causer) {
        if (causer instanceof net.minecraft.class_3222 player) {
            net.minecraft.class_8779 adv = world.method_8503().method_3851().method_12896(net.minecraft.class_2960.method_60655("betterorbitalstrike", "tnt_x18"));
            if (adv != null) player.method_14236().method_12878(adv, "use_tnt_x18");
        }

        for (int i = 0; i < 18; i++) {
            class_1541 tnt = new class_1541(world, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5, causer);
            tnt.method_6967(baseFuse + (i * 1));
            double angle = 2 * Math.PI * i / 18;
            double speed = 0.4;
            tnt.method_18800(Math.cos(angle) * speed, 0.3, Math.sin(angle) * speed);
            world.method_8649(tnt);
        }
    }

    public static void registerModBlocks() {}
}