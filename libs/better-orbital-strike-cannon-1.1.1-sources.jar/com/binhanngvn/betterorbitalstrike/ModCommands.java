package com.binhanngvn.betterorbitalstrike;

import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2277;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class ModCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("betterorbitalstrike")
                    .requires(source -> source.method_9228() != null)
                    .then(class_2170.method_9247("stab_shot")
                            .executes(context -> executeStrikeAtSource(context, "stab_shot"))
                            .then(class_2170.method_9244("pos", class_2277.method_9737())
                                    .executes(context -> executeStrike(context, "stab_shot"))))
                    .then(class_2170.method_9247("nuke_shot")
                            .executes(context -> executeStrikeAtSource(context, "nuke_shot"))
                            .then(class_2170.method_9244("pos", class_2277.method_9737())
                                    .executes(context -> executeStrike(context, "nuke_shot"))))
                    .then(class_2170.method_9247("lawnuke_shot")
                            .executes(context -> executeStrikeAtSource(context, "lawnuke_shot"))
                            .then(class_2170.method_9244("pos", class_2277.method_9737())
                                    .executes(context -> executeStrike(context, "lawnuke_shot"))))
                    .then(class_2170.method_9244("pos", class_2277.method_9737())
                            .then(class_2170.method_9247("stab_shot")
                                    .executes(context -> executeStrike(context, "stab_shot")))
                            .then(class_2170.method_9247("nuke_shot")
                                    .executes(context -> executeStrike(context, "nuke_shot")))
                            .then(class_2170.method_9247("lawnuke_shot")
                                    .executes(context -> executeStrike(context, "lawnuke_shot"))))
            );
        });
    }

    private static int executeStrikeAtSource(CommandContext<class_2168> context, String type) {
        return executeStrike(context.getSource(), context.getSource().method_9222(), type);
    }

    private static int executeStrike(CommandContext<class_2168> context, String type) {
        return executeStrike(context.getSource(), class_2277.method_9736(context, "pos"), type);
    }

    private static int executeStrike(class_2168 source, class_243 pos, String type) {
        class_3218 level = source.method_9225();
        class_2338 blockPos = class_2338.method_49638(pos);
        class_3222 player =
                source.method_9228() instanceof class_3222 serverPlayer ? serverPlayer : null;

        if (type.equals("stab_shot")) {
            OrbitalstrikesLogic.spawnStabStrike(level, blockPos, player);
            source.method_9226(() -> class_2561.method_43470("Calling Stab Shot at: " + format(blockPos)), false);
        } else if (type.equals("nuke_shot")) {
            OrbitalStrikes.runVisualEffect(level, blockPos, 38.0, 60);
            OrbitalstrikesLogic.spawnNuke(level, blockPos, player);
            source.method_9226(() -> class_2561.method_43470("Calling Nuke Shot at: " + format(blockPos)), false);
        } else if (type.equals("lawnuke_shot")) {
            OrbitalStrikes.runVisualEffect(level, blockPos, 65.0, 60);
            OrbitalstrikesLogic.spawnLawnuke(level, blockPos, player);
            source.method_9226(() -> class_2561.method_43470("Calling Lawnuke Shot at: " + format(blockPos)), false);
        }

        return 1;
    }

    private static String format(class_2338 pos) {
        return pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260();
    }
}
