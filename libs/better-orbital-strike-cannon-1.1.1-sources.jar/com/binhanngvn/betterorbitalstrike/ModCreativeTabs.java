package com.binhanngvn.betterorbitalstrike;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModCreativeTabs {
    public static void register() {

        class_1761 group = FabricItemGroup.builder()
                .method_47321(class_2561.method_43471("itemGroup.betterorbitalstrike.main"))
                .method_47320(() -> new class_1799(ModItems.NUKE_CLEAR))
                .method_47317((context, entries) -> {
                    entries.method_45421(ModItems.STAB_SHOT);
                    entries.method_45421(ModItems.NUKE_SHOT);
                    entries.method_45421(ModItems.LAWNUKE_SHOT);
                    entries.method_45421(ModItems.TNT_X9);
                    entries.method_45421(ModItems.TNT_X18);
                    entries.method_45421(ModItems.NUKE_CLEAR);
                })
                .method_47324();

        class_2378.method_10230(
                class_7923.field_44687,
                class_2960.method_60655("betterorbitalstrike", "main"),
                group
        );
    }
}
