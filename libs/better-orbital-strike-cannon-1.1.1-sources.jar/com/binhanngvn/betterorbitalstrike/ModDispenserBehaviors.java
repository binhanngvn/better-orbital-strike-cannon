package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_3218;

public class ModDispenserBehaviors {

    public static void register() {

        // 1. KÍCH HOẠT CHO TNT X9
        class_2315.method_10009(ModBlocks.TNT_X9, new class_2347() {
            @Override
            protected class_1799 method_10135(class_2342 pointer, class_1799 stack) {
                class_3218 world = pointer.comp_1967();
                class_2338 targetPos = pointer.comp_1968().method_10093(pointer.comp_1969().method_11654(class_2315.field_10918));

                ModBlocks.primeTntX9(world, targetPos, 80, null);

                stack.method_7934(1);
                return stack;
            }
        });

        // 2. KÍCH HOẠT CHO TNT X18
        class_2315.method_10009(ModBlocks.TNT_X18, new class_2347() {
            @Override
            protected class_1799 method_10135(class_2342 pointer, class_1799 stack) {
                class_3218 world = pointer.comp_1967();
                class_2338 targetPos = pointer.comp_1968().method_10093(pointer.comp_1969().method_11654(class_2315.field_10918));

                ModBlocks.primeTntX18(world, targetPos, 80, null    );

                stack.method_7934(1);
                return stack;
            }
        });

        // 3. KÍCH HOẠT CHO NUKE CLEAR
        class_2315.method_10009(ModBlocks.NUKE_CLEAR, new class_2347() {
            @Override
            protected class_1799 method_10135(class_2342 pointer, class_1799 stack) {
                class_3218 world = pointer.comp_1967();
                class_2338 targetPos = pointer.comp_1968().method_10093(pointer.comp_1969().method_11654(class_2315.field_10918));

                ModBlocks.primeNukeClear(world, targetPos, null);

                stack.method_7934(1);
                return stack;
            }
        });
    }
}