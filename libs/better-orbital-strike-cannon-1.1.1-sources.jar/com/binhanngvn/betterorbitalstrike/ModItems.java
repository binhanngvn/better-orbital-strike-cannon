package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModItems {
    public static final class_1792 STAB_SHOT    = registerRod("stab_shot");
    public static final class_1792 NUKE_SHOT    = registerRod("nuke_shot");
    public static final class_1792 LAWNUKE_SHOT = registerRod("lawnuke_shot");
    public static final class_1792 TNT_X9       = registerBlockItem("tnt_x9",  ModBlocks.TNT_X9);
    public static final class_1792 TNT_X18      = registerBlockItem("tnt_x18", ModBlocks.TNT_X18);
    public static final class_1792 NUKE_CLEAR   = registerBlockItem("nuke_clear", ModBlocks.NUKE_CLEAR);

    private static class_1792 registerRod(String name) {
        class_2960 id = class_2960.method_60655("betterorbitalstrike", name);
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);

        class_1792 item = new UsedRodItem(
                new class_1792.class_1793()
                        .method_63686(key)
                        .method_7889(1)
                        .method_7895(64)
                        .method_24359()
        );

        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    private static class_1792 registerBlockItem(String name, net.minecraft.class_2248 block) {
        class_2960 id = class_2960.method_60655("betterorbitalstrike", name);
        class_5321<class_1792> key = class_5321.method_29179(class_7924.field_41197, id);
        class_1792 item = new class_1747(block, new class_1792.class_1793().method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    public static void registerModItems() {

    }
}