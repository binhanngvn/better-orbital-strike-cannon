package com.binhanngvn.betterorbitalstrike;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1541;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2315;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class OrbitalStrikeMod implements ModInitializer {

    public static class_1299<AscendingTntEntity> ASCENDING_TNT_ENTITY_TYPE;

    @Override
    public void onInitialize() {

        ASCENDING_TNT_ENTITY_TYPE = class_2378.method_10230(
                class_7923.field_41177,
                class_2960.method_60655("betterorbitalstrike", "ascending_tnt"),
                class_1299.class_1300.method_5903(AscendingTntEntity::new, class_1311.field_17715)
                        .method_17687(0.98F, 0.98F)
                        .method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("betterorbitalstrike", "ascending_tnt")))
        );

        ModBlocks.registerModBlocks();
        ModItems.registerModItems();
        ModCreativeTabs.register();
        ModDispenserBehaviors.register();
        ModCommands.register();

        class_2315.method_10009(class_1802.field_8626, new class_2347() {
            @Override
            protected class_1799 method_10135(class_2342 pointer, class_1799 stack) {
                class_1937 world = pointer.comp_1967();
                var pos = pointer.comp_1968().method_10093(pointer.comp_1969().method_11654(class_2315.field_10918));

                class_1541 tnt = new class_1541(world, pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, null);
                tnt.method_6967(20);
                world.method_8649(tnt);

                stack.method_7934(1);
                return stack;
            }
        });
    }
}