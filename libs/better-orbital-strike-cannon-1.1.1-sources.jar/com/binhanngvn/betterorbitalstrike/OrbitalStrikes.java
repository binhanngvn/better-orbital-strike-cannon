package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_3218;

public class OrbitalStrikes {

    public static void spawnStabRingWave(class_3218 level, class_2338 center) {
        new Thread(() -> {
            double cx = center.method_10263() + 0.5;
            double cz = center.method_10260() + 0.5;

            double maxRadius = 61;

            for (double radius = 2; radius <= maxRadius; radius += 3) {
                double r = radius;

                level.method_8503().execute(() -> {
                    int points = (int)(2 * Math.PI * r);

                    for (int i = 0; i < points; i++) {
                        double angle = 2 * Math.PI * i / points;

                        double x = cx + Math.cos(angle) * r;
                        double z = cz + Math.sin(angle) * r;

                        double dx = x - cx;
                        double dz = z - cz;

                        if (Math.abs(Math.abs(dx) - Math.abs(dz)) > 0.5) continue;

                        class_2338 pos = class_2338.method_49637(x, center.method_10264(), z);

                        OrbitalstrikesLogic.spawnStabStrike(level, pos);
                    }
                });

                try { Thread.sleep(300); } catch (Exception ignored) {}
            }
        }).start();
    }

    public static void runVisualEffect(class_3218 level, class_2338 center, double maxR, int duration) {
        new Thread(() -> {
            double currentR = 0;
            double rot = 0;
            double step = maxR / duration;

            for (int i = 0; i < duration; i++) {
                final double r = currentR;
                final double rotation = rot;

                level.method_8503().execute(() -> {
                    double cx = center.method_10263() + 0.5;
                    double cz = center.method_10260() + 0.5;

                    int circlePoints = (int) (2 * Math.PI * r * 2.5);
                    for (int j = 0; j < circlePoints; j++) {
                        double angle = (2 * Math.PI * j / circlePoints) + rotation;
                        double x = cx + Math.cos(angle) * r;
                        double z = cz + Math.sin(angle) * r;
                        int y = level.method_8624(
                                class_2902.class_2903.field_13203,
                                (int)x,
                                (int)z
                        );

                        for (var player : level.method_18456()) {
                            level.method_14166(
                                    player,
                                    class_2398.field_29644,
                                    true,
                                    true,
                                    x,
                                    y + 0.5,
                                    z,
                                    1,
                                    0,
                                    0,
                                    0,
                                    0
                            );
                        }
                    }
                });

                rot += (0.2 + (r * 0.02));
                currentR += step;
                try { Thread.sleep(50); } catch (Exception ignored) {}
            }
        }).start();
    }

    public static void spawnAscendingBeam(class_3218 level, class_2338 pos) {
        new Thread(() -> {
            double x = pos.method_10263() + 0.5;
            double z = pos.method_10260() + 0.5;

            for (double y = pos.method_10264(); y <= pos.method_10264() + 72.5; y += 0.5) {
                double finalY = y;
                level.method_8503().execute(() -> {
                    for (var player : level.method_18456()) {
                        level.method_14166(
                                player,
                                class_2398.field_29644,
                                true,
                                true,
                                x,
                                finalY + 0.5,
                                z,
                                1,
                                0,
                                0,
                                0,
                                0
                        );
                    }
                });
                try { Thread.sleep(10); } catch (Exception ignored) {}
            }
        }).start();
    }

    public static void spawnAscendingTnt(class_3218 level, class_2338 pos) {
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264();
        double z = pos.method_10260() + 0.5;
        AscendingTntEntity tnt = AscendingTntEntity.create(level, x, y, z);
        level.method_8649(tnt);
    }

    public static void clearAscendingTnt(class_3218 level, class_2338 center) {
        level.method_8503().execute(() -> {
            for (var entity : level.method_8390(
                    AscendingTntEntity.class,
                    new class_238(center).method_1014(100),
                    e -> true
            )) {
                entity.method_31472();
            }
        });
    }
}
