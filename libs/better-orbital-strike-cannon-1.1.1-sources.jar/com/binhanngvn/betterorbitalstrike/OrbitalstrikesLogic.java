package com.binhanngvn.betterorbitalstrike;

import java.util.Random;
import net.minecraft.class_1541;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class OrbitalstrikesLogic {

    private static void spawnTnt(class_3218 world, double x, double y, double z, int fuse) {
        class_1541 tnt = new class_1541(world, x + 0.5, y, z + 0.5, null);
        tnt.method_6967(fuse);
        tnt.method_18800(0, 0, 0);
        world.method_8649(tnt);
    }

    public static void spawnStabStrike(class_3218 world, class_2338 target) {
        spawnStabStrike(world, target, null);
    }

    public static void spawnStabStrike(class_3218 world, class_2338 target, class_3222 player) {

        if (player != null) {
            var advancement = world.method_8503()
                    .method_3851()
                    .method_12896(class_2960.method_60655("betterorbitalstrike", "first_stab_shot"));

            if (advancement != null) {
                player.method_14236()
                        .method_12878(advancement, "use_stab_shot");
            }
        }

        new Thread(() -> {
            int delayTicks = 20;

            for (int i = 0; i < delayTicks; i++) {
                final double rot = i * 0.2;

                world.method_8503().execute(() -> {
                    double cx = target.method_10263() + 0.5;
                    double cz = target.method_10260() + 0.5;
                    int surfaceY = world.method_8624(class_2902.class_2903.field_13203, (int)cx, (int)cz);
                    int points = 25;
                    for (int j = 0; j < points; j++) {
                        double angle = (2 * Math.PI * j / points) + rot;
                        double x = cx + Math.cos(angle) * 2.0;
                        double z = cz + Math.sin(angle) * 2.0;

                        for (var p : world.method_18456()) {
                            world.method_14166(p, class_2398.field_29644, true, true,
                                    x, surfaceY + 0.2, z, 1, 0, 0, 0, 0);
                        }
                    }
                });
                try { Thread.sleep(50); } catch (Exception ignored) {}
            }

            world.method_8503().execute(() -> {
                double cx = target.method_10263() + 0.5;
                double cz = target.method_10260() + 0.5;

                for (int y = -64; y <= 170; y += 2) {
                    spawnTnt(world, cx, y, cz, 0);
                    spawnTnt(world, cx, y, cz, 0);
                }
            });
        }).start();
    }

    public static void spawnNuke(class_3218 world, class_2338 center) {
        spawnNuke(world, center, null);
    }

    public static void spawnNuke(class_3218 world, class_2338 center, class_3222 player) {

        if (player != null) {
            var advancement = world.method_8503()
                    .method_3851()
                    .method_12896(class_2960.method_60655("betterorbitalstrike", "first_nuke_shot"));

            if (advancement != null) {
                player.method_14236()
                        .method_12878(advancement, "use_nuke_shot");
            }
        }

        world.method_8503().execute(() -> {
            double cx = center.method_10263() + 0.5;
            double cz = center.method_10260() + 0.5;
            double spawnY = center.method_10264() + 70.5;
            double spread = 3;
            double gravity = 0;
            int fuse = 100;

            double[] radii = {0.025, 0.05, 0.075, 0.1, 0.125, 0.15, 0.175, 0.2, 0.225, 0.25, 0.275, 0.3};
            int[]   points = {12,    24,   36,    36,  36,    48,   48,    72,  72,    84,   84,    84};

            spawnTntVelocity(world, cx, spawnY, cz, fuse, 0, gravity, 0);

            Random random = new Random(
                    world.method_75260() ^ center.method_10063()
            );

            for (int ri = 0; ri < radii.length; ri++) {

                double r = radii[ri];
                int pts = points[ri];

                double ringOffset =
                        random.nextDouble() * Math.PI * 2;

                for (int i = 0; i < pts; i++) {

                    double step = 2 * Math.PI / pts;

                    double jitter =
                            (random.nextDouble() - 0.5)
                                    * step
                                    * 2.0;

                    double angle =
                            ringOffset
                                    + (step * i)
                                    + jitter;

                    double dx = Math.cos(angle) * r;
                    double dz = Math.sin(angle) * r;

                    spawnTntVelocity(
                            world,
                            cx,
                            spawnY,
                            cz,
                            fuse,
                            dx * spread,
                            gravity,
                            dz * spread
                    );
                }
            }
        });
    }

    public static void spawnLawnuke(class_3218 world, class_2338 center) {
        spawnLawnuke(world, center, null);
    }

    public static void spawnLawnuke(class_3218 world, class_2338 center, class_3222 player) {

        if (player != null) {
            var advancement = world.method_8503()
                    .method_3851()
                    .method_12896(class_2960.method_60655("betterorbitalstrike", "first_lawnuke_shot"));

            if (advancement != null) {
                player.method_14236()
                        .method_12878(advancement, "use_lawnuke_shot");
            }
        }

        world.method_8503().execute(() -> {
            double cx = center.method_10263() + 0.5;
            double cz = center.method_10260() + 0.5;
            double spawnY = center.method_10264() + 70.5;
            double spread = 3;
            double gravity = 0;
            int fuse = 100;

            double[] radii = {0.025, 0.05, 0.075, 0.1, 0.125, 0.15, 0.175, 0.2, 0.225, 0.25, 0.275, 0.3,
                    0.325, 0.35, 0.375, 0.4, 0.425, 0.45, 0.475, 0.5, 0.525, 0.55, 0.575, 0.6, 0.625};
            int[]   points = {12,    24,   24,    36,  36,    36,   48,    48,   48,  72,
                    72,    72,   84,    84,  84,    84,   84,    84,  100,   100,  100,   100, 120};

            spawnTntVelocity(world, cx, spawnY, cz, fuse, 0, gravity, 0);

            Random random = new Random(
                    world.method_75260() ^ center.method_10063()
            );

            for (int ri = 0; ri < radii.length; ri++) {

                double r = radii[ri];
                int pts = points[ri];

                double ringOffset =
                        random.nextDouble() * Math.PI * 2;

                for (int i = 0; i < pts; i++) {

                    double step = 2 * Math.PI / pts;

                    double jitter =
                            (random.nextDouble() - 0.5)
                                    * step
                                    * 2.0;

                    double angle =
                            ringOffset
                                    + (step * i)
                                    + jitter;

                    double dx = Math.cos(angle) * r;
                    double dz = Math.sin(angle) * r;

                    spawnTntVelocity(
                            world,
                            cx,
                            spawnY,
                            cz,
                            fuse,
                            dx * spread,
                            gravity,
                            dz * spread
                    );
                }
            }
        });
    }

    private static void spawnTntVelocity(class_3218 world, double x, double y, double z,
                                         int fuse, double vx, double vy, double vz) {
        class_1541 tnt = new class_1541(world, x, y, z, null);
        tnt.method_6967(fuse);
        tnt.method_18800(vx, vy, vz);
        world.method_8649(tnt);
    }
}