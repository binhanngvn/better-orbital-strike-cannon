package com.binhanngvn.betterorbitalstrike;

import net.minecraft.class_1799;

public class UsedRodItem extends CustomRodItem {

    public UsedRodItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1799 method_7854() {
        class_1799 stack = super.method_7854();
        stack.method_7974(63); // Đặt sẵn 1 độ bền
        return stack;
    }

    @Override
    public boolean method_31567(class_1799 stack) {
        return true;
    }

    // XÓA HOẶC SỬA LẠI PHƯƠNG THỨC NÀY
    @Override
    public int method_31569(class_1799 stack) {
        // Trả về 1 để hiển thị vạch nhỏ nhất
        return 1;
    }

    @Override
    public int method_31571(class_1799 stack) {
        // Ép buộc thanh bar hiển thị màu đỏ (RGB cho màu đỏ là 0xFF0000)
        return 0xFF0000;
    }
}