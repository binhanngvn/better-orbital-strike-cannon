package com.binhanngvn.betterorbitalstrike.client;

import com.binhanngvn.betterorbitalstrike.OrbitalStrikeMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_956;

public class OrbitalStrikeCannonClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(OrbitalStrikeMod.ASCENDING_TNT_ENTITY_TYPE, class_956::new);
	}
}